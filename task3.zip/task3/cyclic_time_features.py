import math
import unittest

# Convert time to cyclic features (sine, cosine) for 24-hour format
def convert_time_to_cyclic_features(hour):
    # Normalize hour to a value between 0 and 2*pi (24 hours to radians)
    angle = (hour % 24) * (2 * math.pi) / 24  # Convert hour to angle
    print(f"Time: {hour}, Angle (radians): {angle}, Sin: {math.sin(angle)}, Cosine: {math.cos(angle)}")  # Debug print
    sin_value = math.sin(angle)
    cos_value = math.cos(angle)
    return sin_value, cos_value

class TestTimeTransformation(unittest.TestCase):

    def test_3pm(self):
        sin, cos = convert_time_to_cyclic_features(15)
        # Test for 3pm
        self.assertAlmostEqual(sin, -0.7071067811865475, places=15)  # Updated expected sin value
        self.assertAlmostEqual(cos, -0.7071067811865479, places=15)  # Updated expected cos value

    def test_9am(self):
        sin, cos = convert_time_to_cyclic_features(9)
        # Test for 9am
        self.assertAlmostEqual(sin, 0.7071067811865476, places=15)  # Expected sin ≈ 0.707
        self.assertAlmostEqual(cos, -0.7071067811865475, places=15)  # Updated expected cos value

    def test_time_difference(self):
        # Testing time difference, expecting a difference of 2 hours between 23:00 and 01:00
        start_time = 23
        end_time = 1
        diff = end_time - start_time if end_time >= start_time else (end_time + 24) - start_time
        self.assertAlmostEqual(diff, 2, places=15)  # Difference should be 2 hours

if __name__ == "__main__":
    unittest.main()

